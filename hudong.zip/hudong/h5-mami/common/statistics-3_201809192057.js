! function () {
    function e(n, o, i) {
        function t(a, d) {
            if (!o[a]) {
                if (!n[a]) {
                    var u = "function" == typeof require && require;
                    if (!d && u) return u(a, !0);
                    if (r) return r(a, !0);
                    var s = new Error("Cannot find module '" + a + "'");
                    throw s.code = "MODULE_NOT_FOUND", s
                }
                var c = o[a] = {
                    exports: {}
                };
                n[a][0].call(c.exports, function (e) {
                    var o = n[a][1][e];
                    return t(o || e)
                }, c, c.exports, e, n, o, i)
            }
            return o[a].exports
        }
        for (var r = "function" == typeof require && require, a = 0; a < i.length; a++) t(i[a]);
        return t
    }
    return e
}()({
    1: [function (e, n, o) {
        ! function (e, n, o) {
            n.cookie = function (e, o, i) {
                if ("undefined" == typeof o) {
                    var t = null;
                    if (document.cookie && "" != document.cookie)
                        for (var r = document.cookie.split(";"), a = 0; a < r.length; a++) {
                            var d = n.trim(r[a]);
                            if (d.substring(0, e.length + 1) == e + "=") {
                                t = decodeURIComponent(d.substring(e.length + 1));
                                break
                            }
                        }
                    return t
                }
                i = i || {}, null === o && (o = "", i = n.extend({}, i), i.expires = -1);
                var u = "";
                if (i.expires && ("number" == typeof i.expires || i.expires.toUTCString)) {
                    var s;
                    "number" == typeof i.expires ? (s = new Date, s.setTime(s.getTime() + 24 * i.expires * 60 * 60 * 1e3)) : s = i.expires, u = "; expires=" + s.toUTCString()
                }
                var c = i.path ? "; path=" + i.path : "",
                    l = i.domain ? "; domain=" + i.domain : "",
                    f = i.secure ? "; secure" : "";
                document.cookie = [e, "=", encodeURIComponent(o), u, c, l, f].join("")
            };
            var i = n.cookie("Ret"),
                t = function (e) {
                    return void 0 === e || "undefined" === e || "" === n.trim(e) || "null" === e ? {} : (e && "string" == typeof e && (e = JSON.parse(e)), e)
                },
                r = {
                    logTimeout: null,
                    $win: n(e),
                    initLog: function () {
                        var e = this;
                        e.showLog(), e.clickLog(), e.srollLog()
                    },
                    singleExp: function (e) {
                        var o, r;
                        if (e = t(e), e.domain) {
                            var a = [];
                            for (var d in e) a.push(encodeURIComponent(d) + "=" + encodeURIComponent(e[d]));
                            o = e.domain + "/exposure/standard?" + a.join("&") + "&_t=" + (new Date).getTime() + "&Ret=" + i
                        }
                        if (e.domain4Web) {
                            var a = [];
                            for (var d in e) a.push(encodeURIComponent(d) + "=" + encodeURIComponent(e[d]));
                            r = e.domain4Web + e.url + "?" + a.join("&") + "&_t=" + (new Date).getTime();
                            n('<img style="display:none;" src="' + r + '">')
                        }
                    },
                    showLog: function (o) {
                        var r = this,
                            a = r.$win.height(),
                            d = r.$win.width();
                        n("body").find("[db-exposure]").not("[db-exposure-get]").each(function () {
                            var u = n(this),
                                s = u.attr("db-exposure");
                            u.offset() && 0 === u.offset().width || n(e).scrollTop() + a >= u.offset().top && n(e).scrollLeft() + d >= u.offset().left && (u.attr("db-exposure-get", !0), s = t(s), s.domain && (s.Ret = i), s.domain4Web && r.sendApi({
                                domain: s.domain4Web,
                                url: s.url,
                                data: s
                            }, function () {
                                o && o()
                            }))
                        })
                    },
                    singleClk: function (e) {
                        var o = this,
                            i = {
                                data: null,
                                callback: function () {}
                            };
                        e = n.extend(!0, i, e);
                        var r = e.data,
                            a = e.callback;
                        r = t(r), r.domain4Web ? o.sendApi({
                            domain: r.domain4Web,
                            url: r.url,
                            data: r
                        }, function () {
                            a && a()
                        }) : a && a()
                    },
                    clickLog: function (e) {
                        var o = this;
                        n("body").find("[db-click]").unbind("click.statistics").bind("click.statistics", function () {
                            var i = n(this),
                                r = i.attr("db-click");
                            "none" === i.css("display") || "disabled" === i.attr("disabled") || i.prop("disabled") || (r = t(r), r.domain4Web && o.sendApi({
                                domain: r.domain4Web,
                                url: r.url,
                                data: r
                            }, function () {
                                e && e()
                            }))
                        })
                    },
                    srollLog: function (e) {
                        var n = this;
                        clearTimeout(n.logTimeout), n.logTimeout = setTimeout(function () {
                            n.$win.scroll(function () {
                                n.showLog()
                            })
                        }, 200)
                    },
                    sendApi: function (e, o, i, t) {
                        try {
                            var r = JSON.stringify(e);
                            if (r.indexOf("iframe") !== -1) return
                        } catch (a) {
                            console.log("数据异常:" + (a || ""))
                        }
                        var d = e.domain || "",
                            u = e.url;
                        d && (delete e.domain, delete e.url, e.data && e.data.domain && delete e.data.domain, n.ajax({
                            url: d + u,
                            data: e.data,
                            dataType: "jsonp",
                            type: "get",
                            timeout: 400,
                            jsonpCallback: "tracks",
                            complete: function () {
                                o && o()
                            },
                            success: function (e) {
                                i && i(e)
                            },
                            error: function (e) {
                                t && t(e)
                            }
                        }))
                    }
                },
                a = function (e) {
                    if (e) {
                        var n = JSON.parse(e),
                            o = [];
                        for (var i in n) o.push(encodeURIComponent(i) + "=" + encodeURIComponent(n[i]));
                        return n.domainWeb + n.url + "?" + o.join("&")
                    }
                };
            o.exposure = r, o.format = a
        }(window, $, window.DB || (window.DB = {}))
    }, {}]
}, {}, [1]);