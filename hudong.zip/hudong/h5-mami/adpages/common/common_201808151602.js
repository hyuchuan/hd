! function () {
    function e(n, t, o) {
        function i(a, d) {
            if (!t[a]) {
                if (!n[a]) {
                    var c = "function" == typeof require && require;
                    if (!d && c) return c(a, !0);
                    if (r) return r(a, !0);
                    var s = new Error("Cannot find module '" + a + "'");
                    throw s.code = "MODULE_NOT_FOUND", s
                }
                var l = t[a] = {
                    exports: {}
                };
                n[a][0].call(l.exports, function (e) {
                    var t = n[a][1][e];
                    return i(t || e)
                }, l, l.exports, e, n, t, o)
            }
            return t[a].exports
        }
        for (var r = "function" == typeof require && require, a = 0; a < o.length; a++) i(o[a]);
        return i
    }
    return e
}()({
    1: [function (e, n, t) {
        var o = {
            options: {},
            init: function (e) {
                var n = this,
                    t = {
                        classPrefix: "style",
                        clickDom: ".J_block",
                        callback: function (e) { }
                    };
                n.options = $.extend({}, t, e), n.getBlock(function (e) {
                    n.render(e), n.performance()
                })
            },
            getBlock: function (e) {
                var _s = this,
                    i = _s.i,
                    x = _s.getPageKey("danType"),
                    M = i.get(x) || [];

                var res = {"code":1,"msg":"\u83b7\u53d6\u6210\u529f","data":{"id":"7","title":"\u5bfb\u627e\u9526\u9ca4\uff0c\u62bd\u5956\u4e0d\u505c","rule":"<p style=\"white-space: normal;\">\u4e00\u3001\u6d3b\u52a8\u53c2\u4e0e<\/p><p style=\"white-space: normal;\">1.\u6d3b\u52a8\u5373\u65e5\u8d77\u81f32019\u5e741\u67081\u65e5\uff0c\u672c\u6b21\u6d3b\u52a8\u63d0\u4f9b\u7684\u793c\u54c1\u6709\u9650\uff0c\u62bd\u5b8c\u5373\u6d3b\u52a8\u7ed3\u675f\uff0c\u4ee5\u5148\u5230\u8005\u4e3a\u51c6\uff1b<\/p><p style=\"white-space: normal;\">2.\u6d3b\u52a8\u671f\u95f4\u6bcf\u4e2a\u7528\u6237\u6bcf\u65e5\u83b7\u53d66\u6b21\u514d\u8d39\u62bd\u5956\u673a\u4f1a\uff1b<\/p><p style=\"white-space: normal;\">&nbsp;<\/p><p style=\"white-space: normal;\">\u4e8c\u3001\u5956\u54c1\u53ca\u4e2d\u5956<\/p><p style=\"white-space: normal;\">1.\u6d3b\u52a8\u5956\u9879\u8bbe\u7f6e\u4e3a\uff1a<\/p><p style=\"white-space: normal;\">\u4e00\u7b49\u5956iphone xs\u4e00\u53f0\uff1b<\/p><p style=\"white-space: normal;\">\u4e8c\u7b49\u5956 \u5c0f\u7c73\u7535\u89c62\u53f0\uff1b<\/p><p style=\"white-space: normal;\">\u4e09\u7b49\u5956 \u626b\u5730\u673a\u5668\u4eba5\u53f0\uff1b<\/p><p style=\"white-space: normal;\">\u5e78\u8fd0\u5956 10000\u540d\uff1b<\/p><p style=\"white-space: normal;\">2.100%\u4e2d\u5956\uff0c\u662f\u6307\u6bcf\u4e2a\u53c2\u4e0e\u62bd\u5956\u7684\u7528\u6237\u5728\u6d3b\u52a8\u671f\u95f4\u90fd\u4f1a\u4e2d\u5956\uff0c\u4f46\u4e0d\u4fdd\u8bc1\u6bcf\u5929\u90fd\u4f1a\u4e2d\u5956\uff1b<\/p><p style=\"white-space: normal;\">3.\u672c\u6b21\u6d3b\u52a8\u63d0\u4f9b\u7684\u793c\u54c1\u6709\u9650\uff0c\u62bd\u5b8c\u5373\u6d3b\u52a8\u7ed3\u675f\u3002<\/p><p><br\/><\/p>","free_num":"6","free_repeat":"1","is_awaken":"1","awaken_type":"1","is_float":"1","float_ad":{"name":"cs1","style":"paperroom","url":"https:\/\/interaction.bayimob.com\/gameHtml?appkey=1dce882c847503b1d2842b74871c58fc&adSpaceKey=aa1decf535cadb08aa5b58f8690add4a&1=1"},"status":"1","games_lobby":"1","awaken":[{"id":"4","name":"\u8c46\u76df16","pic":"http:\/\/192.168.3.83\/data\/active\/20181109163556281.jpg","url":"https:\/\/interaction.bayimob.com\/gameHtml?appkey=1dce882c847503b1d2842b74871c58fc&adSpaceKey=aa1decf535cadb08aa5b58f8690add4a&1=1","type":"1","category":"1","sort":"1"},{"id":"5","name":"\u6d3e\u745e5","pic":"http:\/\/192.168.3.83\/data\/active\/20181109183754672.jpg","url":"http:\/\/interactive.lanzhisky.com\/gt?plat_id=44&media_id=LSBl6f&adv_pos_id=Ys1asm&device_id=__DEVICE__","type":"1","category":"1","sort":"3"},{"id":"8","name":"\u8c46\u76df16","pic":"http:\/\/192.168.3.83\/data\/active\/20181203170101964.jpg","url":"https:\/\/interaction.bayimob.com\/gameHtml?appkey=1dce882c847503b1d2842b74871c58fc&adSpaceKey=aa1decf535cadb08aa5b58f8690add4a&1=1","type":"1","category":"1","sort":"3"},{"id":"7","name":"\u6d3e\u745e5","pic":"http:\/\/192.168.3.83\/data\/active\/20181109184059567.jpg","url":"http:\/\/interactive.lanzhisky.com\/gt?plat_id=44&media_id=LSBl6f&adv_pos_id=Ys1asm&device_id=__DEVICE__","type":"1","category":"1","sort":"5"}],"ads":[{"awardid":"0","activityid":"7","awardname":"\u7ea2\u5305","awardimg":"\/dist\/rotateModel\/img\/447ee13f-d615-448b-b5ce-8dfc7fc58db2","degree":360,"type":"0","key":0},{"awardid":"","activityid":"","awardname":"IPhoneXS","awardimg":"\/dist\/rotateModel\/img\/447ee13f-d615-448b-b5ce-8dfc7fc58db3","degree":300,"type":99,"key":1},{"awardid":"0","activityid":"7","awardname":"\u5e78\u8fd0\u798f\u888b","awardimg":"\/dist\/rotateModel\/img\/a943b87f-4e70-43cd-9109-0f3cfa81772c","degree":240,"type":"0","key":2},{"awardid":"","activityid":"","awardname":"\u626b\u5730\u673a\u5668\u4eba","awardimg":"\/dist\/rotateModel\/img\/9e719b5c-2035-4078-b91e-ae7c390a42d1","degree":180,"type":99,"key":3},{"awardid":"0","activityid":"7","awardname":"\u8d22\u795e","awardimg":"\/dist\/rotateModel\/img\/5cd880f1-c82f-4e23-93d9-cc51d18c2f52","degree":120,"type":"0","key":4},{"awardid":"","activityid":"","awardname":"\u5c0f\u7c73\u7535\u89c6","awardimg":"\/dist\/rotateModel\/img\/ec0e63a6-369e-4380-b223-fb69a7ad49f6","degree":60,"type":99,"key":5}],"cnzz":""}};
                if (!res || res.code != '1') {
                    console.log("请求数据失败");
                    return
                }
                document.title = res.data.title;
                window.CFG.free_num = parseInt(res.data.free_num);
                $(".color-ball-cell .rule-modal .section").html(res.data.rule || '');
                if (res.data.is_float == '1') {
                    var float_ad = res.data.float_ad,
                        float = {
                            el: ".box",
                            floatlink: float_ad.url,
                            uid: window.CFG.uid,
                            channel_id: window.CFG.channel_id,
                            acid: window.CFG.acid,
                            floatId: float_ad.style
                        };
                    $(".floatclick").hasClass("floatclick") || requireFloat(float)
                }
                window.CFG.dayNum = window.CFG.free_num - window.CFG.pi, window.CFG.dayNum <= 0 && (window.CFG.dayNum = 0);
                window.CFG.dayNum == 0 && res.data.free_repeat == '1' && (window.CFG.dayNum = window.CFG.free_num, window.CFG.pi = 0, window.CFG.myPrize = {}, M = []);
                (function () {
                    var o, r = $(".color-ball-cell"),
                        l = $(".color-ball-cell .ball-panel"),
                        c = $(".color-ball-cell .gather-panel"),
                        u = $(".color-ball-cell .gather-panel .gather-progress"),
                        s = $(".color-ball-cell .ball-btn"),
                        d = $(".color-ball-cell .ball-btn .hand"),
                        f = $(".color-ball-cell .ball-btn .dayNum"),
                        g = $(".color-ball-cell .gather-panel .danNum"),
                        p = $(".color-ball-cell .rule"),
                        v = $(".color-ball-cell .rule-modal"),
                        w = $(".color-ball-cell .rule-modal .close"),
                        sr = $(".share .shareBtn"),
                        sk = _s.getPageKey("shareProp"),
                        sn = i.get(sk) || 20,
                        m = !0,
                        h = ["niu", "ling"],
                        y = 0,
                        b = {
                            init: function () {
                                b.fullScreenLayout(), b.dayNum(), b.shareProp(), res.data.cnzz && b.cnzz(res.data.cnzz), res.data.games_lobby == '1' && b.gameroom(), b.event(), b.danTypeState()
                            },
                            event: function () {
                                s.on("click", function () {
                                    if (m) {
                                        m = !1, window.CFG.dayNum-- , window.CFG.pi++ , i.set(pi, window.CFG.pi);
                                        $(this).find(".btn-start").addClass("btn-down"), b.dayNum(), d.hide(), l.children().removeClass("dong").addClass("zhuang");
                                        var t = $(".color-ball-cell .gather-panel .danNum.show");
                                        i.set(k, window.CFG.dayNum), setTimeout(function () {
                                            b.outEgg(t, b.getPrize)
                                        }, 1e3)
                                    } else {
                                        window.CFG.awaken && baseJs.wakeUpPlug({
                                            awaken: window.CFG.awaken,
                                            active_id: window.CFG.acid,
                                            user_id: window.CFG.uid,
                                            channel_id: window.CFG.channel_id,
                                        })
                                    }
                                }), p.on("click", function () {
                                    v.toggleClass("show")
                                }), w.on("click", function () {
                                    v.toggleClass("show")
                                }), sr.on("click", function () {
                                    var data = {
                                        active_id: window.CFG.acid,
                                        user_id: window.CFG.uid,
                                        channel_id: window.CFG.channel_id,
                                        type: 0
                                    };
                                    soshm && soshm.popIn({
                                        title: '弹窗分享',
                                        sites: ['weixin', 'weixintimeline', 'qq'],
                                        callback: function (e) {
                                            window.CFG.dayNum++ , b.dayNum(), i.set(k, window.CFG.dayNum);
                                            window.CFG.pi-- , window.CFG.pi < 0 && (window.CFG.pi = 0), i.set(pi, window.CFG.pi);
                                            e && e == 1 && baseJs.myAlert("复制成功，请发到群里或好友！<br>\n\r中奖概率翻倍哦!", 2000), sn += b.randomNum(5, 10), sn > 80 && (e != 1 && baseJs.myAlert("老板，你的运气已经非常高了，还想干嘛~~", 2000), sn = 80), b.shareProp(), i.set(sk, sn);
                                            s.find(".btn-start").removeClass("disable"), m = !0
                                        }
                                    })
                                }), $(".ball-ke").on("click", function () {
                                    window.CFG.dayNum == 0 && window.CFG.awaken && baseJs.wakeUpPlug({
                                        awaken: window.CFG.awaken,
                                        active_id: window.CFG.acid,
                                        user_id: window.CFG.uid,
                                        channel_id: window.CFG.channel_id,
                                    })
                                })
                            },
                            randomNum: function (s, e) {
                                return parseInt(Math.random() * (e - s) + s)
                            },
                            shareProp: function () {
                                $(".share .num_box").css("top", (100 - sn) + '%').html(sn + '%');
                                $(".share .sp_line .sp_line_img").css("top", (100 - sn) + '%')
                            },
                            gameroom: function () {
                                $('#db-content').prepend('<div class="gameroom"></div>');
                                $(".gameroom").on("click", function () {
                                    baseJs._ajax('http://api.hudongads.com/statistics/game', {
                                        active_id: window.CFG.acid,
                                        user_id: window.CFG.uid,
                                        channel_id: window.CFG.channel_id,
                                        type: 1
                                    }, "GET", !0, function (s) { });
                                    setTimeout(function () {
                                        window.location.href = '/gameroom/#acid=' + window.CFG.acid + '&uid=' + window.CFG.uid + '&channel_id=' + window.CFG.channel_id
                                    }, 200)
                                })
                            },
                            fullScreenLayout: function () {
                                var e = window.innerHeight,
                                    t = window.innerWidth,
                                    n = window.remScale,
                                    o = $("#db-content"),
                                    a = $("#db-content").height(),
                                    i = a / n,
                                    l = [r],
                                    c = Math.round((1 - a / e) / 4 * e),
                                    u = Math.round(t / 15 * 2);
                                return !(!i || o && !o.length) && (!(a >= e) && (c > u && (c = u), c < 0 && (c = 0), a = e, o.css("height", a + "px"), o.css("background-position-y", c - u + "px"), void l.forEach(function (e) {
                                    try {
                                        var t = parseInt(e.css("top").replace("px", "")) + c;
                                        e.css("top", t + "px")
                                    } catch (e) { }
                                })))
                            },
                            dayNum: function () {
                                f.html("今日免费：" + window.CFG.dayNum + "次")
                            },
                            cnzz: function (id) {
                                var s = document.createElement('script');
                                s.src = "https://s96.cnzz.com/z_stat.php?id=" + id + "&web_id=" + id, s.setAttribute('language', 'JavaScript'), document.body.appendChild(s)
                            },
                            danTypeState: function () {
                                M && M.forEach(function (e, t) {
                                    g.eq(e).addClass("show")
                                })
                            },
                            getRandom: function (e, t) {
                                return parseInt(Math.random() * (t - e) + e)
                            },
                            makeEgg: function (e, t, n) {
                                n && ($("." + h[t] + "-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = $("." + h[t], c).index(), -1 === M.indexOf(y) && (M.push(y), i.set(x, M)), h.splice(t, 1))
                            },
                            outEgg: function (e, t) {
                                if (3 === h.length) {
                                    var n = b.getRandom(0, 3);
                                    b.makeEgg(e, n, 1)
                                } else if (2 === h.length) {
                                    var o = b.getRandom(0, 2);
                                    b.makeEgg(e, o, 1)
                                } else if (1 === h.length) b.makeEgg(e, 0, 1);
                                else {
                                    if (b.getRandom(1, 11) > 1) {
                                        var a = b.getRandom(1, 7);
                                        1 === a ? ($(".dan-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 1, -1 === M.indexOf(y) && (M.push(y), i.set(x, M))) : 2 === a ? ($(".chun-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 4) : 3 === a ? ($(".fu-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 5) : 4 === a ? ($(".fu-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 7) : 5 === a ? ($(".li-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 6) : 6 === a && ($(".li-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 8)
                                    } else $(".bao-egg", l).removeClass("dong zhuang").addClass("prize-ing"), y = 3, -1 === M.indexOf(y) && (M.push(y), i.set(x, M))
                                }
                                setTimeout(function () {
                                    t && t()
                                }, 2200)
                            },
                            getPrize: function () {
                                m = !0, l.children().removeClass("zhuang").addClass("dong"), $(".prize-ing", l).removeClass("prize-ing"), s.find(".btn-start").removeClass("btn-down"), y < 4 && (setTimeout(function () {
                                    g.eq(y).addClass("show"), u.addClass("progress-" + M.length)
                                }, 1e3), i.set(C, M.length)), window.CFG.dayNum <= 0 && (m = !1, s.find(".btn-start").addClass("disable")), b.getPlugin()
                            },
                            getPlugin: function () {
                                var e = $("#block_0 .J_block").eq(y).attr("data-type"),
                                    t = $("#block_0 .J_block").eq(y).attr("data-blockname"),
                                    n = $("#block_0 .J_block").eq(y).attr("db-click");
                                this.singleClk({
                                    data: n
                                }), 7 === parseInt(e) && window.EmbedPlugin && window.EmbedPlugin({
                                    section: t,
                                    mainPageType: 3,
                                    cacheKey: "pa-adpages-embed",
                                    cb: function () { },
                                    winCB: function (e) { },
                                    closeCB: function () {
                                        window.CFG.dayNum == 0 && window.CFG.awaken && baseJs.wakeUpPlug({
                                            awaken: window.CFG.awaken,
                                            active_id: window.CFG.acid,
                                            user_id: window.CFG.uid,
                                            channel_id: window.CFG.channel_id,
                                        })
                                    }
                                })
                            },
                            singleClk: function (e) {
                                window.DB && window.DB.exposure && window.DB.exposure.singleClk(e)
                            },
                            singleExp: function (e) {
                                window.DB && window.DB.exposure && window.DB.exposure.singleExp && window.DB.exposure.singleExp(e)
                            }
                        },
                        k = _s.getPageKey("dayNum"),
                        C = _s.getPageKey("ballProgress"),
                        pi = _s.getPageKey("pi");
                    M.sort().reverse(), u.addClass("progress-" + M.length);
                    for (var T = 0; T < M.length; T++) 2 === M[T] ? h.splice(1, 1) : h.splice(M[T], 1);
                    i.set(k, window.CFG.dayNum), window.CFG.dayNum || (m = !1, s.find(".btn-start").addClass("disable")), i.set(x, M);
                    b.init(), f.show()
                })();
                var n = {
                    "code": "0000000",
                    "desc": "成功",
                    "data": {
                        "pageId": 1525,
                        "region": {
                            "icon": {
                                "regionName": "icon",
                                "regionType": 14,
                                "blocks": [{
                                    "id": 76526,
                                    "blockName": "扭",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/cz1c6wy18c.png",
                                    "embeddedPluginId": 1036
                                }, {
                                    "id": 76527,
                                    "blockName": "蛋",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/19jt4fq5cz.png",
                                    "embeddedPluginId": 1035
                                }, {
                                    "id": 76528,
                                    "blockName": "领",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/ufizj4x9qz.png",
                                    "embeddedPluginId": 1034
                                }, {
                                    "id": 76529,
                                    "blockName": "包",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/fikos6sk6o.png",
                                    "embeddedPluginId": 1030
                                }, {
                                    "id": 76530,
                                    "blockName": "纯色",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/fj2os2twfp.png",
                                    "embeddedPluginId": 1029
                                }, {
                                    "id": 76531,
                                    "blockName": "金币雨",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/1e8uro9goo.png",
                                    "embeddedPluginId": 1040
                                }, {
                                    "id": 76532,
                                    "blockName": "开宝箱",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/p79xgmaq9e.png",
                                    "embeddedPluginId": 899
                                }, {
                                    "id": 76533,
                                    "blockName": "金币雨2",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/rdp7uokxcw.png",
                                    "embeddedPluginId": 1043
                                }, {
                                    "id": 76534,
                                    "blockName": "开宝箱2",
                                    "blockType": 7,
                                    "url": "",
                                    "pageId": 1525,
                                    "image": "//yun.tuitiger.com/mami-media/img/amr9r9k33h.png",
                                    "embeddedPluginId": 1042
                                }],
                                "blockNum": 9
                            }
                        }
                    },
                    "success": true
                };
                e && e(n)

            },
            i: {
                set: function (e, t) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                        r = {
                            data: t,
                            expire_time: this.d.format("YYYY-MM-DD", new Date((new Date).getTime() + 24 * n * 3600 * 1e3))
                        };
                    try {
                        window.localStorage.setItem(e, JSON.stringify(r))
                    } catch (e) { }
                },
                get: function (e) {
                    var t = this.d.format(),
                        n = null;
                    try {
                        var o = JSON.parse(window.localStorage.getItem(e));
                        o.expire_time >= t && (n = o.data)
                    } catch (e) { }
                    return n
                },
                remove: function (e) {
                    var t = null;
                    try {
                        t = window.localStorage.getItem(e)
                    } catch (e) { }
                    if (t) try {
                        window.localStorage.removeItem(e)
                    } catch (e) { }
                },
                d: {
                    n: ["日", "一", "二", "三", "四", "五", "六"],
                    format: function () {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "YYYY-MM-DD",
                            t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Date,
                            o = t.getFullYear(),
                            a = t.getMonth() + 1,
                            r = t.getDate(),
                            i = t.getHours(),
                            l = t.getMinutes(),
                            c = t.getSeconds(),
                            u = t.getDay(),
                            s = t.getMilliseconds();
                        return e = e.replace("YYYY", o).replace("MM", String(a)[1] ? a : "0" + a).replace("DD", String(r)[1] ? r : "0" + r).replace("hh", String(i)[1] ? i : "0" + i).replace("mm", String(l)[1] ? l : "0" + l).replace("ss", String(c)[1] ? c : "0" + c).replace("SSS", s).replace("ww", u).replace("WW", this.n[u])
                    },
                    json: function () {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date;
                        return {
                            year: e.getFullYear(),
                            month: e.getMonth() + 1,
                            day: e.getDate(),
                            hour: e.getHours(),
                            minute: e.getMinutes(),
                            second: e.getSeconds(),
                            weekDay: e.getDay(),
                            millisecond: e.getMilliseconds()
                        }
                    }
                },
            },
            getPageKey: function () {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                    t = this.getMainPageType(),
                    n = window.CFG.acid || 0,
                    o = "preview";
                switch (t) {
                    case 1:
                        o = "maninmeet";
                        break;
                    case 2:
                        o = "actCenter";
                        break;
                    case 3:
                        o = "direct";
                        break;
                    case 4:
                        o = "activity";
                        break;
                    case 6:
                        o = "record"
                }
                return o = "T-" + o + "-" + n, e && (o = o + "-" + e), o
            },
            getMainPageType: function () {
                var e = -1;
                switch (window.location.pathname) {
                    case "/mainMeet/index":
                        e = 1;
                        break;
                    case "/actCenter/index":
                        e = 2;
                        break;
                    case "/direct/index":
                        e = 3;
                        break;
                    case "/activity/index":
                        e = 4;
                        break;
                    case "/activity/indexRecord":
                        e = 5;
                        break;
                    case "/pluginTools/preview":
                    case "/plugin/entry.html":
                        e = 0;
                        break;
                    default:
                        e = -1
                }
                return e
            },
            render: function (e) {
                for (var n = this, t = $("#db-content").children(), o = t.length, i = 0; i < o; i++) {
                    var r = t[i].id;
                    if (r) {
                        var a = $("#" + r).attr("data-name");
                        e.data.region && e.data.region[a] ? n.options.renderRegionType ? n.options.renderRegionType(e.data.region[a], r) : n.renderRegionType(e.data.region[a], r) : $("#" + r).hide()
                    }
                }
                n.events(n.options.clickDom), window.DB && window.DB.exposure && window.DB.exposure.initLog(), n.options.callback && n.options.callback(e)
            },
            renderRegionType: function (e, n) {
                var t = this,
                    o = e.blocks,
                    r = e.regionType,
                    a = o.length;
                for (i = 0; i < a; i++) {
                    var d = "",
                        c = o[i];
                    d = '<div class="J_block" data-type="' + c.blockType + '" data-blockname="' + c.blockName + '" data-jumpurl="' + c.url + '" db-exposure=' + c.embedInfo.st_info_dpm_exposure + " db-click=" + c.embedInfo.st_info_dpm_click + ">\n              <img src=" + c.image + ">\n              <span>" + c.blockName + "</span>\n            </div>", $("#" + n).addClass(t.options.classPrefix + "-" + r), $("#" + n).append(d)
                }
            },
            events: function (e) {
                $("" + e).on("click", function () {
                    var e = $(this).attr("data-type"),
                        n = $(this).attr("data-blockname"),
                        t = $(this).attr("data-jumpurl");
                    7 == e ? window.EmbedPlugin && window.EmbedPlugin({
                        section: n,
                        mainPageType: 3,
                        cacheKey: "pa-adpages-embed"
                    }) : window.location.href = t
                })
            },
            swiperInit: function (e) {
                new Swiper(e, {
                    centeredSlides: !0,
                    slidesPerView: "auto",
                    initialSlide: 1,
                    coverflow: {
                        rotate: 0,
                        stretch: 10,
                        depth: 20,
                        modifier: 0
                    }
                })
            },
            getUrlParameter: function (e) {
                var n = "[\\?&]" + e + "=([^&#]*)",
                    t = new RegExp(n),
                    o = t.exec(location.href);
                return null === o ? "" : o[1]
            },
            performance: function (e) {
                if (window.TAPerformance = {}, window.performance && window.performance.timing) {
                    var n = window.performance.timing,
                        t = e || 0,
                        o = this;
                    if (n.loadEventEnd) {
                        var i = n.domComplete - n.domInteractive,
                            r = n.domContentLoadedEventEnd - n.navigationStart,
                            a = n.loadEventEnd - n.navigationStart,
                            d = n.responseEnd - n.navigationStart,
                            c = "/statistics/activityPagePerf.php?type=white&directId=" + CFG.id + "&skinId=" + CFG.skinId + "&consumerId=" + CFG.consumerId + "&slotId=" + CFG.slotId + "&domComplete=" + i + "&domLoaded=" + r + "&onload=" + a + "&white=" + d,
                            s = +new Date,
                            l = {
                                url: c,
                                type: "post",
                                data: {},
                                dataType: "json",
                                success: function () { },
                                error: function () { }
                            };
                        l.data.timestamp = s
                    } else t < 10 && setTimeout(function () {
                        t++ , o.performance(t)
                    }, 1e3)
                }
            }
        };
        window.adpages = o
    }, {}]
}, {}, [1]);