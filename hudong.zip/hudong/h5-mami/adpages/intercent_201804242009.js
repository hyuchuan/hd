! function t(e, r, o) {
    function n(a, s) {
        if (!r[a]) {
            if (!e[a]) {
                var c = "function" == typeof require && require;
                if (!s && c) return c(a, !0);
                if (i) return i(a, !0);
                var u = new Error("Cannot find module '" + a + "'");
                throw u.code = "MODULE_NOT_FOUND", u
            }
            var p = r[a] = {
                exports: {}
            };
            e[a][0].call(p.exports, function (t) {
                var r = e[a][1][t];
                return n(r ? r : t)
            }, p, p.exports, t, e, r, o)
        }
        return r[a].exports
    }
    for (var i = "function" == typeof require && require, a = 0; a < o.length; a++) n(o[a]);
    return n
}({
    1: [function (t, e, r) {
        ! function () {
            function t() {
                if (!history.state) {
                    var t = location.href;
                    history.replaceState({
                        page: "intercept",
                        entered: !1
                    }, "", intercetpUrl), history.pushState({
                        page: "current"
                    }, "", t)
                }
                window.onpopstate = function () {
                    history.state && "intercept" == history.state.page && (history.state.entered || (history.replaceState({
                        page: "intercept",
                        entered: !0
                    }, "", intercetpUrl), r(function () {
                        location.reload()
                    })))
                }
            }

            function e() {
                $.ajax({
                    url: "/activity/getReturnPage",
                    type: "get",
                    data: {
                        slotId: n("slotId"),
                        id: n("id"),
                        login: n("login"),
                        appKey: n("appKey"),
                        deviceId: n("deviceId")
                    },
                    dataType: "json",
                    success: function (e) {
                        e.success && (window.intercetpUrl = e.data.url, intercetpUrl && t())
                    },
                    error: function () {
                        console.log("network error")
                    }
                })
            }

            function r(t) {
                $.ajax({
                    url: "/activity/updateReturnTimes",
                    type: "post",
                    data: {
                        slotId: n("slotId")
                    },
                    dataType: "json",
                    success: function (e) {
                        e.success ? t & t() : console.log("Update times error")
                    },
                    error: function () {
                        console.log("network error")
                    }
                })
            }

            function o() {
                return !(!n("tenter") || "SOW" !== n("tenter"))
            }

            function n(t) {
                var e = "[\\?&]" + t + "=([^&#]*)",
                    r = new RegExp(e),
                    o = r.exec(location.href);
                return null === o ? "" : o[1]
            }
            $(function () {
                history.pushState && (history.state ? window.onpopstate = function (t) {
                    history.state && "current" == history.state.page ? location.reload() : history.state && "intercept" == history.state.page && (history.state.entered ? history.go(-1) : (history.state.entered = !0, r(function () {
                        location.reload()
                    })))
                } : o() && e())
            })
        }(Zepto)
    }, {}]
}, {}, [1]);