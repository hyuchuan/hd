! function n(o, t, s) {
    function a(i, l) {
        if (!t[i]) {
            if (!o[i]) {
                var r = "function" == typeof require && require;
                if (!l && r) return r(i, !0);
                if (e) return e(i, !0);
                var c = new Error("Cannot find module '" + i + "'");
                throw c.code = "MODULE_NOT_FOUND", c
            }
            var d = t[i] = {
                exports: {}
            };
            o[i][0].call(d.exports, function (n) {
                var t = o[i][1][n];
                return a(t ? t : n)
            }, d, d.exports, n, o, t, s)
        }
        return t[i].exports
    }
    for (var e = "function" == typeof require && require, i = 0; i < s.length; i++) a(s[i]);
    return a
}({
    1: [function (n, o, t) {
        ! function (o) {
            function t() {
                var n = window.adsbygoogle;
                return !!n && !!(n.loaded || Array.isArray(n) && n[0].loaded)
            }
            var s = function (n) {
                    window.CFG.googleModalId && window.googleModal && t() ? window.googleModal.addDom().show(n) : new a(n)
                },
                a = function (t) {
                    var s = this,
                        a = n("./tpl");
                    this.lottery = t.result.lottery, s.isJPG(this.lottery.block1 && this.lottery.block1.bannerUrl) && "function" == typeof "".ossimg && (this.lottery.block1.bannerUrl = this.lottery.block1.bannerUrl.ossimg()), s.isJPG(this.lottery.block2 && this.lottery.block2.bannerUrl) && "function" == typeof "".ossimg && (this.lottery.block2.bannerUrl = this.lottery.block2.bannerUrl.ossimg()), o("body").append(a(this.lottery)), window.DB.exposure && window.DB.exposure.singleExp(this.lottery.stRecommendInfo), this.lottery.block1 && (window.DB.exposure && window.DB.exposure.singleExp(this.lottery.block1.exposure), this.lottery.block2 && window.DB.exposure && window.DB.exposure.singleExp(this.lottery.block2.exposure)), s.events(t)
                };
            a.prototype.events = function (n) {
                var t = this;
                o(".thanks-modal").on("click", ".thanks-record, .thanks-btn-b", function () {
                    window.DB.exposure && window.DB.exposure.singleClk({
                        data: t.lottery.block3.click,
                        callback: function () {
                            o(".thanks-modal").remove(), n.callback && n.callback.close && n.callback.close(), window.location.href = t.lottery.block3.actUrl
                        }
                    })
                }), o(".thanks-modal").on("click", ".thanks-content", function () {
                    var n;
                    n = o(this).hasClass("content1") ? t.lottery.block1 : t.lottery.block2;
                    var s = {
                        openUrl: n.openUrl || "",
                        iosDownloadUrl: n.iosDownloadUrl || "",
                        androidDownloadUrl: n.androidDownloadUrl || "",
                        confirm: n.confirm || "",
                        advertId: n.advertId,
                        title: n.title
                    };
                    window.DB.exposure.singleClk({
                        data: n.click,
                        callback: function () {
                            s && (window.downloadAppConfig = s, window.downloadApp())
                        }
                    })
                }), o(".thanks-modal").on("click", ".modal-close", function () {
                    window.DB.exposure && window.DB.exposure.singleClk({
                        data: t.lottery.closeClick,
                        callback: function () {
                            o(".thanks-modal").remove(), n.callback && n.callback.close ? n.callback.close() : t.prize.noreload || window.location.reload()
                        }
                    })
                })
            }, a.prototype.isJPG = function (n) {
                var o = !1;
                if (n) {
                    var t = n.split(".");
                    o = t.length > 0 && ("jpg" === t[t.length - 1] || "png" === t[t.length - 1])
                }
                return o
            }, window.showThanks = s
        }(Zepto)
    }, {
        "./tpl": 2
    }],
    2: [function (n, o, t) {
        var s = function (n, o) {
            var t = void 0,
                s = "//yun.tuisnake.com/h5-mami/thanksPrize/body1.png",
                a = "//yun.tuisnake.com/h5-mami/thanksPrize/body2.png",
                e = "//yun.tuisnake.com/h5-mami/thanksPrize/body3.png",
                i = "//yun.tuisnake.com/h5-mami/thanksPrize/thanks-btn-s.png",
                l = "//yun.tuisnake.com/h5-mami/thanksPrize/thanks-btn-b.png",
                r = "未使用",
                c = "我的奖品";
            return window.CFG && 1 == CFG.overseas && (s = "//yun.tuisnake.com/h5-mami/thanksPrize/body1-overseas.png", a = "//yun.tuisnake.com/h5-mami/thanksPrize/body2-overseas.png", e = "//yun.tuisnake.com/h5-mami/thanksPrize/body3-overseas.png", i = "//yun.tuisnake.com/h5-mami/thanksPrize/use-now.png", l = "//yun.tuisnake.com/h5-mami/thanksPrize/thanks-btn-b-overseas.png", r = "unused", c = "My prizes"), t = n && n.block1 && n.block2 ? '<div class="thanks-body1" style="background-image: url(' + s + ');">\n      <div class="thanks-content content1">\n        <img class="thanks-img" src="' + n.block1.bannerUrl + '">\n        <span class="thanks-tip">' + r + '</span>\n        <div class="thanks-btn-s" style="background-image: url(' + i + ');"></div>\n      </div>\n      <div class="thanks-content content2">\n        <img class="thanks-img" src="' + n.block2.bannerUrl + '">\n        <span class="thanks-tip">' + r + '</span>\n        <div class="thanks-btn-s" style="background-image: url(' + i + ');"></div>\n      </div>\n      <div class="thanks-record">' + c + " &gt;</div>\n    </div>" : n && n.block1 ? '<div class="thanks-body2" style="background-image: url(' + a + ');">\n      <div class="thanks-content content1">\n        <img class="thanks-img" src="' + n.block1.bannerUrl + '">\n        <span class="thanks-tip">' + r + '</span>\n        <div class="thanks-btn-s" style="background-image: url(' + i + ');"></div>\n      </div>\n      <div class="thanks-record">' + c + " &gt;</div>\n    </div>" : '<div class="thanks-body3" style="background-image: url(' + e + ');">\n      <div class="thanks-btn-b" style="background-image: url(' + l + ');"></div>\n    </div>', '\n    <div class="thanks-modal" id="thanks-modal">\n      <i class="modal-close"></i>\n      ' + t + "\n    </div>\n  "
        };
        o.exports = s
    }, {}]
}, {}, [1]);