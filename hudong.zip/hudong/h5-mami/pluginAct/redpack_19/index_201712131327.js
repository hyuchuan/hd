!function n(o, e, i) {
    function t(c, s) {
        if (!e[c]) {
            if (!o[c]) {
                var u = "function" == typeof require && require;
                if (!s && u) return u(c, !0);
                if (r) return r(c, !0);
                var p = new Error("Cannot find module '" + c + "'");
                throw p.code = "MODULE_NOT_FOUND", p
            }
            var a = e[c] = {exports: {}};
            o[c][0].call(a.exports, function (n) {
                var e = o[c][1][n];
                return t(e ? e : n)
            }, a, a.exports, n, o, e, i)
        }
        return e[c].exports
    }

    for (var r = "function" == typeof require && require, c = 0; c < i.length; c++) t(i[c]);
    return t
}({
    1: [function (n, o, e) {
        var i = n("./util"), t = {
            events: {}, getOrder: function r() {
                var n = this;
                (function () {
                    var o = {
                        "code": "0000000",
                        "desc": "成功",
                        "data": {"orderId": "179935539730507", "success": true, "message": "成功"},
                        "success": true
                    };
                    o.success ? setTimeout(function () {
                        n.getLottery(o.data.orderId)
                    }, 500) : n.trigger("lose")
                })()
            }, getLottery: function (n) {
                var o = this, e = window.Plugin_Act_CFG.skinId;
                var prize_ids = [];
                for (var pr in window.CFG.myPrize) {
                    prize_ids.push(window.CFG.myPrize[pr].awardid)
                }
                var e = {};
                e && e.data && e.data.awaken && (window.CFG.awaken = e.data.awaken);
                if (e.code !== 1) {
                    o.trigger("lose");
                    return
                }
                var c = window.CFG, awardid = e.data.id, k = c.acid + '#' + awardid, prize = {};
                prize.awardid = awardid, prize.img = e.data.cover_pic, prize.title = e.data.name, prize.url = e.data.url, prize.rqy = window.CFG.urlHead + '/active/receive/?active_id=' + c.acid + '&user_id=' + c.uid + '&prize_id=' + awardid + '&channel_id=' + c.channel_id, prize.awardtype = e.data.type, e.data.type == '1' && (prize.account = e.data.account, prize.qrcode = e.data.qrcode), window.CFG.myPrize[k] = prize;
                try {
                    localStorage.setItem("myPrize", JSON.stringify(window.CFG.myPrize))
                } catch (a) {
                    baseJs.setCookie("myPrize", JSON.stringify(window.CFG.myPrize))
                }
                var e = {
                    "code": "0000000",
                    "desc": "成功",
                    "data": {
                        "result": 2,
                        "activityId": 1029,
                        "orderId": "179935539730507",
                        "lottery": {
                            "link": e.data.url,
                            "rqy": prize.rqy,
                            "tempFlag": 0,
                            "useBtnText": "免费办理",
                            "title": e.data.name,
                            "type": "lucky",
                            "imgurl": e.data.cover_pic,
                            "linkTo": 0,
                            "encourage": {
                                "encourageStatus": 0,
                                "encourageMoney": "0",
                                "encourageMoneyAll": "0",
                                "url": "",
                                "enable": 1,
                                "withdrawalAmount": "0",
                                "encourageEmbedData": {},
                                "showType": 1
                            },
                            "encourageFlag": false,
                            "tip": "一句话描述",
                            "id": 53980,
                            "validate": "2018-12-31",
                            "androidDownloadUrl": e.data.url,
                            "advertId": 34708,
                            "openUrl": "",
                            "showUse": true,
                            "iosDownloadUrl": e.data.url,
                            "isDownloadUrl": true,
                        },
                        "detailContactInfo": {"isOpenOptionDetail": true, "optionDetailPhone": "4000806659"},
                        "status": "success"
                    },
                    "success": true
                }
                if (e.success) {
                    var i = e.data, t = i.status, r = i.lottery;
                    if ("success" === t) {
                        var c = r.type;
                        "lucky" === c || "coupon" === c ? o.trigger("win", r) : o.trigger("lose")
                    } else o.trigger("lose")
                } else o.trigger("lose")
            }, trigger: function (n) {
                for (var o = this.events[n], e = 0, i = o.length; e < i; e++) o[e].apply(null, [].slice.call(arguments, 1))
            }, on: function (n, o) {
                (this.events[n] = this.events[n] || []).push(o)
            }
        };
        o.exports = t
    }, {"./util": 3}], 2: [function (n, o, e) {
        var i = n("../common/flow"), t = {
            init: function (n) {
                var o = n.pluginBtn || $(".plugin-act-popup .plugin-act-btn"),
                    e = n.closeBtn || $(".plugin-act-popup .plugin-act-close"), i = n.orderBox || $(".winred .order"),
                    t = n.orderName || $(".winred .decs"), r = n.winredBtn || $(".winred .plugin-coupon-btn");
                this.beforehand(o, e), this.onFlowsEvents(i, e, r, t, n.winpackShow, n.nonepackShow, n.changeProcess)
            }, beforehand: function (n, o) {
                var e = window.Plugin_Act_CFG.embedData;
                window.DB && window.DB.exposure && window.DB.exposure.singleExp(e)
            }, hideModal: function (n, o) {
                var o = o || $("#popup .plugin-act-close"),
                    e = o.attr("db-click") || window.Plugin_Act_CFG.closeClickEmbedData;
                e ? window.DB && window.DB.exposure && window.DB.exposure.singleClk({data: e, callback: n}) : n()
            }, format: function (n) {
                if (n) {
                    var o = JSON.parse(n), e = [];
                    for (var i in o) e.push(encodeURIComponent(i) + "=" + encodeURIComponent(o[i]));
                    return o.domainWeb + "/exposure/plugin?" + e.join("&")
                }
            }, onFlowsEvents: function (n, o, e, t, r, c, s) {
                i.on("win", function (i) {
                    function c(n) {
                        n.preventDefault();
                        var o = i.st_info_dpm_img_click, e = function () {
                            setTimeout(function () {
                                window.location.href = i.link
                            }, 200)
                        };
                        window.DB && window.DB.exposure && window.DB.exposure.singleClk({data: o, callback: e})
                    }

                    s(), window.DB && window.DB.exposure && window.DB.exposure.singleExp(i.st_info_dpm_img), n.html("<img src='" + i.imgurl + "'>"), n.on("click", c), e.on("click", c), o.attr("db-click", i.st_info_dpm_btn_close), t.html(i.title), r()
                }), i.on("lose", function () {
                    s(), c()
                })
            }, getOrder: function () {
                i.getOrder()
            }
        };
        o.exports = t
    }, {"../common/flow": 1}], 3: [function (n, o, e) {
        var i = {
            ajax: function (n) {
                var o = {
                    data: {timestamp: (new Date).getTime()}, dataType: "json", success: function () {
                    }, error: function (n, o) {
                        "timeout" === o ? (n && n.abort(), console.error("请求超时")) : console.error("网络错误")
                    }
                };
                n = $.extend(!0, o, n), $.ajax(n)
            }
        };
        o.exports = i
    }, {}], 4: [function (n, o, e) {
        var i = n("../common/index-2");
        FastClick(document.body);
        var t = !1, r = {
            $popup: $("#popup"),
            $shadow: $("#popup .popup-shadow"),
            $popupMc: $("#popup .plugin-popup-mc"),
            $rules: $("#popup .plugin-rules"),
            $nonepack: $("#popup .nonepack"),
            $winred: $("#popup .winred"),
            init: function () {
                var n = {
                    winpackShow: this.winpackShow,
                    nonepackShow: this.nonepackShow,
                    changeProcess: this.changeProcess
                };
                i.init(n), this.getCoupon(), this.onPageEvents()
            },
            winpackShow: function () {
                setTimeout(function () {
                    r.$popupMc.hide(), r.$winred.addClass("show")
                }, 2e3)
            },
            nonepackShow: function () {
                r.$popupMc.hide(), r.$nonepack.show()
            },
            hideModal: function () {
                window.CFG.dayNum == 0 && window.CFG.awaken && baseJs.wakeUpPlug({
                    awaken: window.CFG.awaken,
                    active_id: window.CFG.acid,
                    user_id: window.CFG.uid,
                    channel_id: window.CFG.channel_id,
                });
                i.hideModal(function () {
                    r.$popup.hide()
                })
            },
            showrule: function () {
            },
            hiderule: function () {
            },
            showmorerule: function () {
            },
            backhome: function () {
                $("#popup .plugin-act-close").removeAttr("db-click")
            },
            getCoupon: function () {
                t || (t = !0, i.getOrder())
            },
            onPageEvents: function () {
                this.$popup.find(".plugin-act-close").on("click", this.hideModal.bind(this)), this.$popup.find(".playagain").on("click", this.backhome.bind(this)), this.$popup.find(".plugin-act-btn").on("click", this.getCoupon.bind(this)), this.$rules.find(".rules-close").on("click", this.hiderule.bind(this)), this.$rules.find(".btn-more").on("click", this.showmorerule.bind(this)), this.$popupMc.find(".btn-rules").on("click", this.showrule.bind(this))
            },
            changeProcess: function () {
                t = !t
            }
        };
        r.init()
    }, {"../common/index-2": 2}]
}, {}, [4]);