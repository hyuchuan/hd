!function n(o, e, t) {
	function i(c, s) {
		if (!e[c]) {
			if (!o[c]) {
				var u = "function" == typeof require && require;
				if (!s && u) return u(c, !0);
				if (r) return r(c, !0);
				var a = new Error("Cannot find module '" + c + "'");
				throw a.code = "MODULE_NOT_FOUND", a
			}
			var p = e[c] = {
				exports: {}
			};
			o[c][0].call(p.exports, function(n) {
				var e = o[c][1][n];
				return i(e ? e : n)
			}, p, p.exports, n, o, e, t)
		}
		return e[c].exports
	}
	for (var r = "function" == typeof require && require, c = 0; c < t.length; c++) i(t[c]);
	return i
}({
	1: [function(n, o, e) {
		var t = n("./util"),
			i = {
				events: {},
				getOrder: function r() {
					var n = this;
					(function() {
						var o = {
							"code": "0000000",
							"desc": "成功",
							"data": {
								"orderId": "179935539730507",
								"success": true,
								"message": "成功"
							},
							"success": true
						};
						o.success ? setTimeout(function() {
							n.getLottery(o.data.orderId)
						}, 500) : n.trigger("lose")
					})()
				},
				getLottery: function(n) {
					var o = this,
						e = window.Plugin_Act_CFG.skinId;
					var prize_ids = [];
					for (var pr in window.CFG.myPrize) {
						prize_ids.push(window.CFG.myPrize[pr].awardid)
                    }
                    
                    var e = {"code":1,"msg":"\u62bd\u5956\u6210\u529f","data":{"id":"8","name":"(\u4e13\u5c5e) \u514d\u8d39\u9001\u5929\u4f7f\u4e4b\u5251","cover_pic":"http:\/\/192.168.3.83\/data\/active\/20181206170957320.png","type":"2","category":"0","qrcode":"http:\/\/192.168.3.83\/data\/active\/20181025120123986.jpg","account":"xinxinbaby530","url":"http:\/\/h5.37.com\/dtsh5\/?refer=h5_37yypt&uid=dtsh5_sytjkv","pop_rule":"0","degree":240,"key":2}};
                    e && e.data && e.data.awaken && (window.CFG.awaken = e.data.awaken);
							if (e.code !== 1) {
								o.trigger("lose");
								return
							}
							var c = window.CFG,
								awardid = e.data.id,
								k = c.acid + '#' + awardid,
								prize = {};
							prize.awardid = awardid, prize.img = e.data.cover_pic, prize.title = e.data.name, prize.url = e.data.url, prize.rqy = window.CFG.urlHead + '/active/receive/?active_id=' + c.acid + '&user_id=' + c.uid + '&prize_id=' + awardid + '&channel_id=' + c.channel_id, prize.awardtype = e.data.type, e.data.type == '1' && (prize.account = e.data.account, prize.qrcode = e.data.qrcode), window.CFG.myPrize[k] = prize;
							try {
								localStorage.setItem("myPrize", JSON.stringify(window.CFG.myPrize))
							} catch (a) {
								baseJs.setCookie("myPrize", JSON.stringify(window.CFG.myPrize))
							}
							var e = {
								"code": "0000000",
								"desc": "成功",
								"data": {
									"result": 2,
									"activityId": 1029,
									"orderId": "179935539730507",
									"lottery": {
										"link": e.data.url,
										"rqy": prize.rqy,
										"tempFlag": 0,
										"useBtnText": "免费办理",
										"title": e.data.name,
										"type": "lucky",
										"imgurl": e.data.cover_pic,
										"linkTo": 0,
										"encourage": {
											"encourageStatus": 0,
											"encourageMoney": "0",
											"encourageMoneyAll": "0",
											"url": "",
											"enable": 1,
											"withdrawalAmount": "0",
											"encourageEmbedData": {},
											"showType": 1
										},
										"encourageFlag": false,
										"tip": "一句话描述",
										"id": 53980,
										"validate": "2018-12-31",
										"androidDownloadUrl": e.data.url,
										"advertId": 34708,
										"openUrl": "",
										"showUse": true,
										"iosDownloadUrl": e.data.url,
										"isDownloadUrl": true,
									},
									"detailContactInfo": {
										"isOpenOptionDetail": true,
										"optionDetailPhone": "4000806659"
									},
									"status": "success"
								},
								"success": true
							};
							if (e.success) {
								var i = e.data,
									t = i.status,
									r = i.lottery;
								if ("success" === t) {
									var c = r.type;
									"lucky" === c || "coupon" === c ? o.trigger("win", r) : o.trigger("lose")
								} else o.trigger("lose")
							} else o.trigger("lose")
				},
				trigger: function(n) {
					for (var o = this.events[n], e = 0, t = o.length; e < t; e++) o[e].apply(null, [].slice.call(arguments, 1))
				},
				on: function(n, o) {
					(this.events[n] = this.events[n] || []).push(o)
				}
			};
		o.exports = i
	}, {
		"./util": 3
	}],
	2: [function(n, o, e) {
		var t = n("../common/flow"),
			i = {
				init: function(n) {
					var o = n.pluginBtn || $(".plugin-act-popup .plugin-act-btn"),
						e = n.closeBtn || $(".plugin-act-popup .plugin-act-close"),
						t = n.orderBox || $(".winred .order"),
						i = n.orderName || $(".winred .decs"),
						r = n.winredBtn || $(".winred .plugin-coupon-btn");
					this.beforehand(o, e), this.onFlowsEvents(t, e, r, i, n.winpackShow, n.nonepackShow, n.changeProcess)
				},
				beforehand: function(n, o) {
					var e = window.Plugin_Act_CFG.embedData;
					window.DB && window.DB.exposure && window.DB.exposure.singleExp(e)
				},
				hideModal: function(n, o) {
					var o = o || $("#popup .plugin-act-close"),
						e = o.attr("db-click") || window.Plugin_Act_CFG.closeClickEmbedData;
					e ? window.DB && window.DB.exposure && window.DB.exposure.singleClk({
						data: e,
						callback: n
					}) : n()
				},
				format: function(n) {
					if (n) {
						var o = JSON.parse(n),
							e = [];
						for (var t in o) e.push(encodeURIComponent(t) + "=" + encodeURIComponent(o[t]));
						return o.domainWeb + "/exposure/plugin?" + e.join("&")
					}
				},
				onFlowsEvents: function(n, o, e, i, r, c, s) {
					t.on("win", function(t) {
						function c(n) {
							n.preventDefault();
							var o = t.st_info_dpm_img_click,
								e = function() {
									setTimeout(function() {
										window.location.href = t.link
									}, 200)
								};
							window.DB && window.DB.exposure && window.DB.exposure.singleClk({
								data: o,
								callback: e
							})
						}
						s(), window.DB && window.DB.exposure && window.DB.exposure.singleExp(t.st_info_dpm_img), n.html("<img src='" + t.imgurl + "'>"), n.on("click", c), e.on("click", c), o.attr("db-click", t.st_info_dpm_btn_close), i.html(t.title), r()
					}), t.on("lose", function() {
						s(), c()
					})
				},
				getOrder: function() {
					t.getOrder()
				}
			};
		o.exports = i
	}, {
		"../common/flow": 1
	}],
	3: [function(n, o, e) {
		var t = {
			ajax: function(n) {
				var o = {
					data: {
						timestamp: (new Date).getTime()
					},
					dataType: "json",
					success: function() {},
					error: function(n, o) {
						"timeout" === o ? (n && n.abort(), console.error("请求超时")) : console.error("网络错误")
					}
				};
				n = $.extend(!0, o, n), $.ajax(n)
			}
		};
		o.exports = t
	}, {}],
	4: [function(n, o, e) {
		var t = n("../common/index-2");
		FastClick(document.body);
		var i = !1,
			r = {
				$popup: $("#popup"),
				$start: $("#popup .plugin-act-btn"),
				$close: $("#popup .plugin-act-close"),
				$init: $("#popup .init"),
				$nonepack: $("#popup .nonepack"),
				$winred: $("#popup .winred"),
				init: function() {
					var n = {
						winredBtn: $("#popup .plugin-coupon-btn"),
						winpackShow: this.wined,
						nonepackShow: this.failed,
						changeProcess: this.changeProcess
					};
					t.init(n), this.onPageEvents()
				},
				wined: function() {
					r.$popup.addClass("active")
				},
				failed: function() {
					r.$nonepack.show(), r.$winred.hide(), r.$init.hide()
				},
				hideModal: function() {
					window.CFG.dayNum == 0 && window.CFG.awaken && baseJs.wakeUpPlug({
						awaken: window.CFG.awaken,
						active_id: window.CFG.acid,
						user_id: window.CFG.uid,
						channel_id: window.CFG.channel_id,
					});
					t.hideModal(function() {
						r.$popup.hide()
					})
				},
				getCoupon: function() {
					i || (i = !0, setTimeout(function() {
						t.getOrder()
					}, 0))
				},
				onPageEvents: function() {
					r.$close.on("click", this.hideModal.bind(this)), r.$start.on("click", this.getCoupon.bind(this))
				},
				changeProcess: function() {
					i = !i
				}
			};
		r.init()
	}, {
		"../common/index-2": 2
	}]
}, {}, [4]);