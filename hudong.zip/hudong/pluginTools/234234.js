/*! 构建时间:2018-9-29 10:56:19;构建人:ylxdeMacBook-Pro.local */
webpackJsonp(["plugin-skins-niudan_dan-entry"], {
	"+E39": function(e, t, n) {
		e.exports = !n("S82l")(function() {
			return 7 != Object.defineProperty({}, "a", {
				get: function() {
					return 7
				}
			}).a
		})
	},
	"+ZMJ": function(e, t, n) {
		var o = n("lOnJ");
		e.exports = function(e, t, n) {
			if (o(e), void 0 === t) return e;
			switch (n) {
			case 1:
				return function(n) {
					return e.call(t, n)
				};
			case 2:
				return function(n, o) {
					return e.call(t, n, o)
				};
			case 3:
				return function(n, o, r) {
					return e.call(t, n, o, r)
				}
			}
			return function() {
				return e.apply(t, arguments)
			}
		}
	},
	"77Pl": function(e, t, n) {
		var o = n("EqjI");
		e.exports = function(e) {
			if (!o(e)) throw TypeError(e + " is not an object!");
			return e
		}
	},
	"7KvD": function(e, t) {
		var n = e.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
		"number" == typeof __g && (__g = n)
	},
	"9bBU": function(e, t, n) {
		n("mClu");
		var o = n("FeBl").Object;
		e.exports = function(e, t, n) {
			return o.defineProperty(e, t, n)
		}
	},
	C4MV: function(e, t, n) {
		e.exports = {
		default:
			n("9bBU"), __esModule: !0
		}
	},
	D2L2: function(e, t) {
		var n = {}.hasOwnProperty;
		e.exports = function(e, t) {
			return n.call(e, t)
		}
	},
	EqjI: function(e, t) {
		e.exports = function(e) {
			return "object" == typeof e ? null !== e : "function" == typeof e
		}
	},
	FeBl: function(e, t) {
		var n = e.exports = {
			version: "2.5.7"
		};
		"number" == typeof __e && (__e = n)
	},
	MmMw: function(e, t, n) {
		var o = n("EqjI");
		e.exports = function(e, t) {
			if (!o(e)) return e;
			var n, r;
			if (t && "function" == typeof(n = e.toString) && !o(r = n.call(e))) return r;
			if ("function" == typeof(n = e.valueOf) && !o(r = n.call(e))) return r;
			if (!t && "function" == typeof(n = e.toString) && !o(r = n.call(e))) return r;
			throw TypeError("Can't convert object to primitive value")
		}
	},
	ON07: function(e, t, n) {
		var o = n("EqjI"),
			r = n("7KvD").document,
			i = o(r) && o(r.createElement);
		e.exports = function(e) {
			return i ? r.createElement(e) : {}
		}
	},
	S82l: function(e, t) {
		e.exports = function(e) {
			try {
				return !!e()
			} catch (e) {
				return !0
			}
		}
	},
	SfB7: function(e, t, n) {
		e.exports = !n("+E39") && !n("S82l")(function() {
			return 7 != Object.defineProperty(n("ON07")("div"), "a", {
				get: function() {
					return 7
				}
			}).a
		})
	},
	WVqv: function(e, t) {},
	WwcQ: function(e, t, n) {
		Object.defineProperty(t, "__esModule", {
			value: !0
		});
		var o = u(n("Zrlr")),
			r = u(n("wxAW")),
			i = u(n("mvHQ")),
			a = u(n("kEHT"));

		function u(e) {
			return e && e.__esModule ? e : {
			default:
				e
			}
		}
		var c = {
			set: function(e, t) {
				var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
					o = new Date;
				o.setHours(23, 59, 59, 59);
				var r = o.getTime() + 24 * n * 60 * 60 * 1e3,
					a = new Date(r);
				document.cookie = e + "=" + (0, i.
			default)(t) + ";expires=" + a
			},
			get: function(e) {
				var t = null,
					n = e + "=";
				if (document.cookie.length) for (var o = document.cookie.split(";"), r = 0; r < o.length; r++) {
					var i = o[r].trim();
					if (0 === i.indexOf(n)) {
						t = JSON.parse(i.substring(n.length, i.length));
						break
					}
				}
				return t
			},
			remove: function(e) {
				if (document.cookie.length) {
					var t = new Date;
					t.setTime(t.getTime() - 864e5), document.cookie = e + "=;expires=" + t
				}
			}
		},
			l = function() {
				function e(t) {
					(0, o.
				default)(this, e), this.cache = c, window.localStorage && (this.cache = a.
				default)
				}
				return (0, r.
			default)(e, [{
					key: "set",
					value: function(e, t) {
						var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
						this.cache.set(e, t, n)
					}
				}, {
					key: "get",
					value: function(e) {
						return this.cache.get(e)
					}
				}, {
					key: "update",
					value: function(e, t) {
						var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
						this.cache.update && this.cache.update(e, t, n)
					}
				}, {
					key: "remove",
					value: function(e) {
						this.cache.remove(e)
					}
				}]), e
			}();
		t.
	default = l
	},
	X8DO: function(e, t) {
		e.exports = function(e, t) {
			return {
				enumerable: !(1 & e),
				configurable: !(2 & e),
				writable: !(4 & e),
				value: t
			}
		}
	},
	Zrlr: function(e, t, n) {
		"use strict";
		t.__esModule = !0, t.
	default = function(e, t) {
			if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
		}
	},
	evD5: function(e, t, n) {
		var o = n("77Pl"),
			r = n("SfB7"),
			i = n("MmMw"),
			a = Object.defineProperty;
		t.f = n("+E39") ? Object.defineProperty : function(e, t, n) {
			if (o(e), t = i(t, !0), o(n), r) try {
				return a(e, t, n)
			} catch (e) {}
			if ("get" in n || "set" in n) throw TypeError("Accessors not supported!");
			return "value" in n && (e[t] = n.value), e
		}
	},
	hJx8: function(e, t, n) {
		var o = n("evD5"),
			r = n("X8DO");
		e.exports = n("+E39") ?
		function(e, t, n) {
			return o.f(e, t, r(1, n))
		} : function(e, t, n) {
			return e[t] = n, e
		}
	},
	kEHT: function(e, t, n) {
		Object.defineProperty(t, "__esModule", {
			value: !0
		});
		var o = i(n("mvHQ")),
			r = i(n("lI+A"));

		function i(e) {
			return e && e.__esModule ? e : {
			default:
				e
			}
		}
		var a = {
			set: function(e, t) {
				var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
					i = {
						data: t,
						expire_time: r.
					default.format("YYYY-MM-DD", new Date((new Date).getTime() + 24 * n * 3600 * 1e3))
					};
				try {
					window.localStorage.setItem(e, (0, o.
				default)(i))
				} catch (e) {}
			},
			get: function(e) {
				var t = r.
			default.format(),
					n = null;
				try {
					var o = JSON.parse(window.localStorage.getItem(e));
					o.expire_time >= t && (n = o.data)
				} catch (e) {}
				return n
			},
			update: function(e, t, n) {
				var i = JSON.parse(window.localStorage.getItem(e));
				t && (i.data = t), n && (i.expire_time = r.
			default.format("YYYY-MM-DD", new Date(new Date(i.expire_time).getTime() + 24 * n * 3600 * 1e3)));
				try {
					window.localStorage.setItem(e, (0, o.
				default)(i))
				} catch (e) {}
			},
			remove: function(e) {
				var t = null;
				try {
					t = window.localStorage.getItem(e)
				} catch (e) {}
				if (t) try {
					window.localStorage.removeItem(e)
				} catch (e) {}
			}
		};
		t.
	default = a
	},
	kM2E: function(e, t, n) {
		var o = n("7KvD"),
			r = n("FeBl"),
			i = n("+ZMJ"),
			a = n("hJx8"),
			u = n("D2L2"),
			c = function(e, t, n) {
				var l, f, s, d = e & c.F,
					p = e & c.G,
					g = e & c.S,
					v = e & c.P,
					w = e & c.B,
					h = e & c.W,
					y = p ? r : r[t] || (r[t] = {}),
					m = y.prototype,
					b = p ? o : g ? o[t] : (o[t] || {}).prototype;
				for (l in p && (n = t), n)(f = !d && b && void 0 !== b[l]) && u(y, l) || (s = f ? b[l] : n[l], y[l] = p && "function" != typeof b[l] ? n[l] : w && f ? i(s, o) : h && b[l] == s ?
				function(e) {
					var t = function(t, n, o) {
							if (this instanceof e) {
								switch (arguments.length) {
								case 0:
									return new e;
								case 1:
									return new e(t);
								case 2:
									return new e(t, n)
								}
								return new e(t, n, o)
							}
							return e.apply(this, arguments)
						};
					return t.prototype = e.prototype, t
				}(s) : v && "function" == typeof s ? i(Function.call, s) : s, v && ((y.virtual || (y.virtual = {}))[l] = s, e & c.R && m && !m[l] && a(m, l, s)))
			};
		c.F = 1, c.G = 2, c.S = 4, c.P = 8, c.B = 16, c.W = 32, c.U = 64, c.R = 128, e.exports = c
	},
	"lI+A": function(e, t) {
		Object.defineProperty(t, "__esModule", {
			value: !0
		});
		var n, o = (n = ["日", "一", "二", "三", "四", "五", "六"], {
			format: function() {
				var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "YYYY-MM-DD",
					t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : new Date,
					o = t.getFullYear(),
					r = t.getMonth() + 1,
					i = t.getDate(),
					a = t.getHours(),
					u = t.getMinutes(),
					c = t.getSeconds(),
					l = t.getDay(),
					f = t.getMilliseconds();
				return e = e.replace("YYYY", o).replace("MM", String(r)[1] ? r : "0" + r).replace("DD", String(i)[1] ? i : "0" + i).replace("hh", String(a)[1] ? a : "0" + a).replace("mm", String(u)[1] ? u : "0" + u).replace("ss", String(c)[1] ? c : "0" + c).replace("SSS", f).replace("ww", l).replace("WW", n[l])
			},
			json: function() {
				var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : new Date;
				return {
					year: e.getFullYear(),
					month: e.getMonth() + 1,
					day: e.getDate(),
					hour: e.getHours(),
					minute: e.getMinutes(),
					second: e.getSeconds(),
					weekDay: e.getDay(),
					millisecond: e.getMilliseconds()
				}
			}
		});
		t.
	default = o
	},
	lOnJ: function(e, t) {
		e.exports = function(e) {
			if ("function" != typeof e) throw TypeError(e + " is not a function!");
			return e
		}
	},
	mClu: function(e, t, n) {
		var o = n("kM2E");
		o(o.S + o.F * !n("+E39"), "Object", {
			defineProperty: n("evD5").f
		})
	},
	mvHQ: function(e, t, n) {
		e.exports = {
		default:
			n("qkKv"), __esModule: !0
		}
	},
	n95b: function(e, t) {
		Object.defineProperty(t, "__esModule", {
			value: !0
		});
		var n = {
			ajax: function(e) {
				var t = this,
					n = {
						data: {
							timestamp: (new Date).getTime()
						},
						dataType: "json",
						success: function() {},
						error: function(e, t) {
							"timeout" === t && e && e.abort()
						}
					};
				if (e = $.extend(!0, n, e), window.CFG && window.CFG.isGlobalToken && window.CFG.globalToken) {
					var o = window.CFG.globalToken,
						r = e.success;
					return e.success = function(n) {
						if (n && "9999998" === n.code) return t.getActivityIframeToken(function() {
							o = window.CFG.globalToken, e.data.globalToken = o, $.ajax(e)
						}), !1;
						r(n)
					}, e.data.globalToken = o, $.ajax(e), !1
				}
				$.ajax(e)
			},
			getActivityIframeToken: function(e) {
				if (window.CFG && window.CFG.isRequestToken) {
					var t = setInterval(function() {
						window.CFG.isRequestToken || (clearInterval(t), e())
					});
					return !1
				}
				window.CFG.isRequestToken = !0, $.ajax({
					url: "/token/getGlobalToken",
					type: "get",
					dataType: "json",
					data: {
						appId: window.CFG && window.CFG.appId,
						deviceId: this.getUrlParameter("deviceId"),
						slotId: window.CFG && window.CFG.slotId
					},
					success: function(e) {
						window.CFG && (window.CFG.globalToken = e.data || "")
					},
					complete: function() {
						e(), window.CFG.isRequestToken = !1
					}
				})
			},
			getUrlParameter: function(e) {
				var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : window.location.href,
					n = decodeURIComponent((new RegExp("[?|&]" + e + "=([^&;]+?)(&|#|;|$)").exec(t) || [void 0, ""])[1].replace(/\+/g, "%20")) || null;
				return n ? n.split("/")[0] : ""
			},
			getBroEnv: function() {
				for (var e = navigator.userAgent.toLocaleLowerCase(), t = [{
					rgx: /qq/g,
					val: 2
				}, {
					rgx: /micromessenger/g,
					val: 1
				}, {
					rgx: /alipay/g,
					val: 3
				}], n = 4, o = 0; o < t.length; o++) e.match(t[o].rgx) && (n = t[o].val);
				return n
			},
			getMainPageType: function() {
				var e = -1;
				switch (window.location.pathname) {
				case "/mainMeet/index":
					e = 1;
					break;
				case "/actCenter/index":
					e = 2;
					break;
				case "/direct/index":
					e = 3;
					break;
				case "/activity/index":
					e = 4;
					break;
				case "/activity/indexRecord":
					e = 5;
					break;
				case "/pluginTools/preview":
				case "/plugin/entry.html":
					e = 0;
					break;
				default:
					e = -1
				}
				return e
			},
			getPageKey: function() {
				var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
					t = this.getMainPageType(),
					n = this.getUrlParameter("id") || 0,
					o = "preview";
				switch (t) {
				case 1:
					o = "maninmeet";
					break;
				case 2:
					o = "actCenter";
					break;
				case 3:
					o = "direct";
					break;
				case 4:
					o = "activity";
					break;
				case 6:
					o = "record"
				}
				return o = "T-" + o + "-" + n, e && (o = o + "-" + e), o
			},
			getDeviceId: function() {
				var e = "";
				try {
					var t = JSON.parse(window.localStorage.getItem("T-activity-Middle-deviceId"));
					t && (e = t.data)
				} catch (e) {}
				return e
			}
		};
		t.
	default = n
	},
	"plugin-skins-niudan_dan-entry-executeModules": function(e, t, n) {
		e.exports = n("qZX8")
	},
	qZX8: function(e, t, n) {
		n("WVqv");
		var o = i(n("WwcQ")),
			r = i(n("n95b"));

		function i(e) {
			return e && e.__esModule ? e : {
			default:
				e
			}
		}
		var a = new o.
	default;
		window.TA.pluginSkin.niudan_dan = {
			$popWin: $(".pop-win"),
			$popLose: $(".pop-lose"),
			init: function() {
				var e = {
					$plugin: $("#plugin"),
					$closeBtn: $("#plugin .j-close-btn"),
					$couponBtn: $("#plugin .j-act-btn"),
					$couponImg: $("#plugin .j-coupon-img"),
					$couponText: $("#plugin .j-coupon-title")
				};
				pluginAct.start(e, {
					author: "莫羽琦",
					intro: "20180711-扭蛋机_包-沈梦婷",
					type: "auto"
				}), this.watch(), this.hander(), this.acScore(), this.fullScreenLayout()
			},
			fullScreenLayout: function() {
				var e = window.innerHeight,
					t = window.innerWidth,
					n = window.remScale,
					o = $("#plugin"),
					r = $("#plugin").height(),
					i = r / n,
					a = [$("#plugin_all")],
					u = Math.round((1 - r / e) / 4 * e),
					c = Math.round(t / 15 * 2);
				return !(!i || o && !o.length) && (!(r >= e) && (u > c && (u = c), u < 0 && (u = 0), r = e, o.css("height", r + "px"), o.css("background-position-y", u - c + "px"), void a.forEach(function(e) {
					try {
						var t = parseInt(e.css("top").replace("px", "")) + u;
						e.css("top", t + "px")
					} catch (e) {}
				})))
			},
			watch: function() {
				var e = this.win.bind(this),
					t = this.lucky.bind(this),
					n = this.lose.bind(this);
				pluginAct.on("win", e).on("lucky", t).on("lose", n)
			},
			acScore: function() {
				var e = r.
			default.getPageKey("ballProgress"),
					t = r.
				default.getPageKey("danType"),
					n = a.get(e),
					o = a.get(t);
				if (n && $(".flow").addClass("showScore" + n), o) for (var i = 0; i < o.length; i++) 1 === o[i] && $("#plugin .award .dan").removeClass("bshow"), $("#plugin .award .p-danNum").eq(o[i]).addClass("show")
			},
			hander: function() {
				pluginAct.autoPlay()
			},
			win: function() {
				$(".pop-win").show()
			},
			lucky: function() {},
			lose: function() {
				$("#plugin .award").hide(), $("#plugin .egg").hide(), $("#plugin .niudan2").hide(), $("#plugin .pop-win").hide(), $("#plugin .pop-lose").show()
			}
		}
	},
	qkKv: function(e, t, n) {
		var o = n("FeBl"),
			r = o.JSON || (o.JSON = {
				stringify: JSON.stringify
			});
		e.exports = function(e) {
			return r.stringify.apply(r, arguments)
		}
	},
	wxAW: function(e, t, n) {
		"use strict";
		t.__esModule = !0;
		var o, r = n("C4MV"),
			i = (o = r) && o.__esModule ? o : {
			default:
				o
			};
		t.
	default = function() {
			function e(e, t) {
				for (var n = 0; n < t.length; n++) {
					var o = t[n];
					o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), (0, i.
				default)(e, o.key, o)
				}
			}
			return function(t, n, o) {
				return n && e(t.prototype, n), o && e(t, o), t
			}
		}()
	}
}, ["plugin-skins-niudan_dan-entry-executeModules"]);