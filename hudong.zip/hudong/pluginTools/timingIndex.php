<?php
echo '{"code":"E0400019","desc":"广告位插件按钮关闭","data":null,"success":false}';