(function (doc, win) {
    var docEl = doc.documentElement,
        resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
        recalc = function () {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            if(clientWidth >=750){
                clientWidth = 750;
            }
            docEl.style.fontSize = 20 * ( clientWidth/ 375) + 'px';
        };
    if (!doc.addEventListener) return;
    win.addEventListener(resizeEvt, recalc, false);
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);
$(function () {
    var active_id = baseJs._getQueryString('active_id') || 0;
    $('#infoForm input[name=active_id]').val(active_id);
    var awardid = baseJs._getQueryString('awardid') || 0;
    $('#infoForm input[name=awardid]').val(awardid);
    var channel_id = baseJs._getQueryString('channel_id') || 0;
    $('#infoForm input[name=channel_id]').val(channel_id);
    var uid = baseJs._getQueryString('uid') || '';
    $('#infoForm input[name=uid]').val(uid);
    var awardTimer = !0;

    var params = {
        active_id: active_id,
        user_id: uid,
        channel_id: channel_id,
        prize_id: awardid,
        type: 0,
    };

    var apiUrl = 'http://api.hudongads.com/statistics/order';

    baseJs._ajax(apiUrl, params, "POST", !0, function(s) {});

    $('.back').on('click',function () {
        window.history.back();
    })
    $(".close").on('click', function () {
        $(".popup").hide();
    })
    $(".service").on('click', function () {
        $(".popup").show();
    })
    $(".cancel").on('click',function(){
        $(".payup").hide();
    })
    var copyBtn = document.querySelector('.copy');
    copyBtn.setAttribute('text','hyc_wx');
    var clcupv = new window.clcupv();
    clcupv.init(copyBtn, function (a) {
        if(a == 1){
            baseJs.myAlert('复制成功,请打开微信查找!', 1000);
        }else{
            baseJs.myAlert('复制失败,请手动选择复制!', 1000);
        }
    });
    $('.weixin').on('click',function () {
        window.location.href = 'weixin://';
    })
    $('#infoForm').on('submit', function (e) {
        e.preventDefault();
        var name = $('.name').val();
        if (name === '') {
            baseJs.myAlert('请填写姓名！');
            return false;
        } else if (new RegExp("[ ,\\`,\\~,\\!,\\@,\#,\\$,\\%,\\^,\\+,\\*,\\&,\\\\,\\/,\\?,\\|,\\:,\\.,\\，,\\。,\\·,\\<,\\>,\\{,\\},\\(,\\),\\',\\;,\\=,\"]").test(name)) {
            baseJs.myAlert('姓名不能包含特殊字符。');
            $('.name').focus();
            return false;
        } else if (!/^[\u4E00-\u9FA5]+$/.test(name)) {
            baseJs.myAlert('请填写中文名字！');
            $('.name').focus();
            return false;
        } else if (name.length > 6) {
            baseJs.myAlert('姓名字数最多为6个字！');
            $('.name').focus();
            return false;
        }

        var telephone = $('.number').val();
        if (telephone === '' || telephone.length != 11 || !/^[1]([0-9]{10})$/.test(telephone)) {
            baseJs.myAlert('手机号码格式错误，请正确输入！');
            $('.number').focus();
            return false;
        }

        var address = $('.address').val();
        if (address.length < 5) {
            baseJs.myAlert('请正确输入地址！');
            $('.address').focus();
            return false;
        }
        params.type = 1;
        baseJs._ajax(apiUrl, params, "POST", !0, function(s) {});
        showAwardTime();
        if(awardTimer) {
            $(".payup").show();
        }else{
            baseJs.myAlert('您已经超时！');
        }

    })
    function showAwardTime() {
        if(window.showAwardTimer){return false};
        window.showAwardTimer = !0;
        var key = active_id + '_' + awardid + 'timer', time = parseInt(baseJs.getCookieStorage(key)), now = +new Date;
        if(!time){
            time = now, baseJs.setCookieStorage(key, time);
        }
        var remainTime = 15*60*1000, costTime = now - time;
        if(costTime > 3600*12*1000){
            time = now, baseJs.setCookieStorage(key, time), costTime = 0;
        }
        remainTime = remainTime - costTime;
        if(remainTime <= 0){
            awardTimer = !1;
            return false;
        }
        function showTimer() {
            if(remainTime <= 0){
                awardTimer = !1,$('.paypop p').html('您已经超时！'),$('.paypop .pay').prop('disabled',true).css({background:'#cecece',boxShadow:'0 0.75rem 0.75rem -0.5rem rgba(206, 206, 206, 0.5)'});
                return false;
            }
            console.log(remainTime);
            var timeStr = PadLeft(parseInt(remainTime / 60000).toString()) + ':' + PadLeft(parseInt((remainTime/1000)%60).toString());
            $('.paypop .time').html(timeStr);
            remainTime-=1000;
            setTimeout(showTimer,1000);
        }
        function PadLeft(str) {
            if(str.length < 2){
                return '0'+str;
            }else{
                return str+'';
            }
        }
        showTimer();
    }

    $('.pay').on('click',function () {
        var _this = $(this);
        _this.prop('disabled',true);
        $('body').append('<div id="alertBg"><p class="text">领奖的路上。。。。。</p></div>');
        params.type = 2;
        baseJs._ajax(apiUrl, params, "POST", !0, function(s) {});
        var data = $('#infoForm').serialize();
        $.ajax({
            url: 'http://hd.781nys.com/hbpay/i.php',
            type: 'POST',
            data: data,
            dataType: "json",
            success:function (data) {
                _this.prop('disabled',false),$('#alertBg').remove();
                if(data['status'] === 0){
                    baseJs.myAlert(data['msg']);
                }
                if(data['status'] === 1){
                    window.location.href = data['payUrl'];
                }
            },
            error:function () {
                _this.prop('disabled',false),$('#alertBg').remove();
            }
        })
    })
})